<?php

$con = mysqli_connect('sql6.freemysqlhosting.net','sql6408202','lXuT18G82u','	sql6408202');
// Check connection
if (mysqli_connect_errno())
{
 echo "Failed to connect to MySQL: " . mysqli_connect_error();
}
?>