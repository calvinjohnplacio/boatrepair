<footer>
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    &copy;  Online Course Registration | By : BSIT-NT-3102 student
                </div>

            </div>
        </div>
    </footer>