<?php
define('DB_SERVERs','localhost');
define('DB_USERs','root');
define('DB_PASSs' ,'');
define('DB_NAMEs', 'courseware');
$con = mysqli_connect(DB_SERVERs,DB_USERs,DB_PASSs,DB_NAMEs);
// Check connection
if (mysqli_connect_errno())
{
 echo "Failed to connect to MySQL: " . mysqli_connect_error();
}
?>