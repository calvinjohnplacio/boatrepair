<section class="menu-section">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="navbar-collapse collapse ">
                        <ul id="menu-top" class="nav navbar-nav navbar-right">
                             <li><a href="Addprod.php">Services</a></li>
                             <li><a href="repairm.php">Repair records</a></li>
                              <li><a href="my-profile.php">My Profile</a></li>
                               <li><a href="change-passwordM.php"><img src="icons\Update.png" width="20" height="20" >Change Password</a></li>
                            <li><a href="logout.php"><img src="icons\logout.png" width="20" height="20" >Logout</a></li>

                        </ul>
                    </div>
                </div>

            </div>
        </div>
    </section>